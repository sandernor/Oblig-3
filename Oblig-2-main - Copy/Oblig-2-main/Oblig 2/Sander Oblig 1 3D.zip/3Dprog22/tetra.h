//#ifndef TETRA_H
//#define TETRA_H


//#include <QOpenGLFunctions_4_1_Core>
//#include <vector>
//#include "vertex.h"

//class TETRA : protected QOpenGLFunctions_4_1_Core
//{
//private:
//   std::vector<Vertex0> mVertices;
//   //QOpenGLContext *mContext;

//public:
//   TETRA();
//   //void setContext(QOpenGLContext *context);
//   void init(GLuint mVAO, GLuint mVBO);
//   void draw();
//};

//#endif // TETRA_H
