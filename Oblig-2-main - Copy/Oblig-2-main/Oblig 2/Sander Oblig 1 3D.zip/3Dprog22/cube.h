//#ifndef CUBE_H
//#define CUBE_H

//#include <QOpenGLFunctions_4_1_Core>
//#include <QMatrix4x4>
//#include <vector>
//#include "vertex.h"

//class CUBE : protected QOpenGLFunctions_4_1_Core
//{
//private:
//   std::vector<Vertex0> mVertices;
//   //QOpenGLContext *mContext;

//public:
//   CUBE();
//   //void setContext(QOpenGLContext *context);
//   void init(GLuint mVAO, GLuint mVBO);
//   void draw();
//};

//#endif // CUBE_H
