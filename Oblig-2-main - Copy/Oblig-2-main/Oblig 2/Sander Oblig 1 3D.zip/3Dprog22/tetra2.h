#ifndef TETRA2_H
#define TETRA2_H

#include <QOpenGLFunctions_4_1_Core>
#include <QMatrix4x4>
#include <vector>
#include "vertex2.h"
#include "visualobject.h"

class TETRA : public VisualObject
{
private:

public:
    TETRA();
    ~TETRA() override;
    void init(GLint matrixUniform) override;
    void draw() override;
    void rotate() override;
};

#endif // CUBE2_H
