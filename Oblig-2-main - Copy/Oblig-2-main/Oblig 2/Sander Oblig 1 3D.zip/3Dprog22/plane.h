#ifndef PLANE_H
#define PLANE_H


#include <QOpenGLFunctions_4_1_Core>
#include <vector>
#include "vertex.h"

class PLANE : protected QOpenGLFunctions_4_1_Core
{
private:
   std::vector<Vertex0> mVertices;
   //QOpenGLContext *mContext;

public:
   PLANE();
   //void setContext(QOpenGLContext *context);
   void init(GLuint mVAO, GLuint mVBO);
   void draw();
};

#endif // PLANE_H
