#include "fxy.h"

fxy::fxy()
{
    float xmin=-1.0f, xmax=1.0f, ymin=-1.0f, ymax=1.0f, h=0.06f;
    for (auto x=xmin; x<xmax; x+=h)
    for (auto y=ymin; y<ymax; y+=h)
    {
    float z = sin(M_PI*x)*sin(M_PI*y);
    mVertices.push_back(Vertex{x,y,z,(x+1)/2,y,((x+y)/2)*(-1)});
    z = sin(M_PI*(x+h))*sin(M_PI*y);
    mVertices.push_back(Vertex{x+h,y,z,x,(y+1)/2,z});
    z = sin(M_PI*x)*sin(M_PI*(y+h));
    mVertices.push_back(Vertex{x,y+h,z,(x+1)/2,y,((x+y)/2)*(-1)});
    mVertices.push_back(Vertex{x,y+h,z,x,(y+1)/2,z});
    z = sin(M_PI*(x+h))*sin(M_PI*y);
    mVertices.push_back(Vertex{x+h,y,z,(x+1)/2,y,((x+y)/2)*(-1)});
    z = sin(M_PI*(x+h))*sin(M_PI*(y+h));
    mVertices.push_back(Vertex{x+h,y+h,z,x,(y+1)/2,z});
    }
   mMatrix.setToIdentity();


}

fxy::~fxy()
{

}

void fxy::init(GLint matrixUniform)
{
   mMatrixUniform = matrixUniform;

   initializeOpenGLFunctions();

   //Vertex Array Object - VAO
   glGenVertexArrays( 1, &mVAO );
   glBindVertexArray( mVAO );

   //Vertex Buffer Object to hold vertices - VBO
   glGenBuffers( 1, &mVBO );
   glBindBuffer( GL_ARRAY_BUFFER, mVBO );

   glBufferData( GL_ARRAY_BUFFER, mVertices.size()*sizeof( Vertex ), mVertices.data(), GL_STATIC_DRAW );

   // 1rst attribute buffer : vertices
   glBindBuffer(GL_ARRAY_BUFFER, mVBO);
   glVertexAttribPointer(0, 3, GL_FLOAT,GL_FALSE, sizeof(Vertex), reinterpret_cast<GLvoid*>(0));
   glEnableVertexAttribArray(0);

   // 2nd attribute buffer : colors
   glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE,  sizeof( Vertex ),  reinterpret_cast<GLvoid*>(3 * sizeof(GLfloat)) );
   glEnableVertexAttribArray(1);

   //enable the matrixUniform
   // mMatrixUniform = glGetUniformLocation( matrixUniform, "matrix" );

   glBindVertexArray(0);
}

void fxy::draw()
{
//   glBindVertexArray( mVAO );
//   glUniformMatrix4fv( mMatrixUniform, 1, GL_FALSE, mMatrix.constData());
    //   glDrawArrays(GL_LINES, 0, mVertices.size());
}

void fxy::rotate()
{
    //mMatrix.rotate(10.f, 0.f, 1.0f, 0.f);
}
void fxy::write(std::string filnavn)
{
    std::ofstream outf{ filnavn };
        if (!outf)
        {
            std::cerr << "Warning: " << filnavn << " could not be written to!\n";
        }

        outf << mVertices.size() << '\n';
        foreach (auto Vertex, mVertices) {
            outf << Vertex <<'\n';
        }

        outf.close();
        mVertices.clear();
}
