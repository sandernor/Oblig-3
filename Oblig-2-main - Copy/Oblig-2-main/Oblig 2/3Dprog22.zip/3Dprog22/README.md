# 3Dprog22
Kode for kurset 3D-programmering, våren 2022.

Koden skal være kompatibel med Qt 6.x.x

Dere skal lage en egen branch av mainbranchen inne i dette repositoriet. **Kall branchen din noe med ditt eget ekte navn**, så vi ser hvem sin branch det er.

I din egen branch kan du leke deg og gjøre forandringer av hjertens lyst (men ikke push noe til Main-branchen). 
**Det eneste du ikke får lov til er å skifte navnet på mappen som repositoriet ligger i. Den må hete "3Dprog22".**
